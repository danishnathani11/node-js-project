const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));


let tasks = {
    description,
    priority,
    status: 'Pending'
  };
{
  tasks.push(newTask);
  res.redirect('/');
};

app.get('/edit-task/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const task = tasks.find(task => task.id === id);

  res.render('edit-task', { task });
});

app.post('/update-task/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { title, description, priority, status } = req.body;

  tasks = tasks.map(task => {
    if (task.id === id) {
      return {
        ...task,
        title,
        description,
        priority,
        status
      };
    }
    return task;
  });

  res.redirect('/');
});

app.get('/delete-task/:id', (req, res) => {
  const id = parseInt(req.params.id);
  tasks = tasks.filter(task => task.id !== id);
  res.redirect('/');
});

app.get('/change-status/:id', (req, res) => {
  const id = parseInt(req.params.id);

  tasks = tasks.map(task => {
    if (task.id === id) {
      if (task.status === 'Pending') {
        task.status = 'In Progress';
      } else if (task.status === 'In Progress') {
        task.status = 'Completed';
      } else {
        task.status = 'Pending';
      }
    }
    return task;
  });

  res.redirect('/');
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});